import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import ffn
import pandas_datareader.data as web
import sqlite3 as db
import matplotlib
import iexfinance

from datetime import datetime
from iexfinance.stocks import get_historical_data


matplotlib.use('TkAgg') #if plots won't show; include this line of code
np.seterr(divide='ignore', invalid='ignore')

num_days = 3570
index = pd.date_range('03/01/2009',periods=num_days, freq='D')

data1 = pd.DataFrame((np.random.randn(num_days) + np.random.uniform(low=0.0, high=0.2, size=num_days)),index=index,columns=['RReturns1'])
data2 = pd.DataFrame((np.random.randn(num_days) + np.random.uniform(low=0.0, high=0.2, size=num_days)),index=index,columns=['RReturns2'])
data3 = pd.DataFrame((np.random.randn(num_days) + np.random.uniform(low=0.0, high=0.2, size=num_days)),index=index,columns=['RReturns3'])
data4 = pd.DataFrame((np.random.randn(num_days) + np.random.uniform(low=0.0, high=0.2, size=num_days)),index=index,columns=['RReturns4'])

data = pd.concat([data1,data2,data3,data4],axis=1)
data = data.cumsum() + 100
data.iloc[0] = 100
data.head()

perf = data.calc_stats() #using random data for generalization

print(type(perf))

perf.plot()
plt.show()

# Define Your Time Horizon (YYYY/MM/DD)

start = datetime(2016,11,1)
end = datetime(2019,2,27)

# Create a Static List of Assets from SQL Query

#database = 'C:/sqlite/sql_databases/sp500.db'

#sql = 'SELECT ticker FROM sp500_const WHERE sector = "Financials";'

#cnx = db.connect(database)
#cur = cnx.cursor()

#tickers = pd.read_sql(sql, con=cnx)

tickers = ['AMG', 'AFL', 'ALL', 'AXP', 'AIG', 'AMP', 'AON', 'AJG', 'AIZ', 'BAC', 'BK', 'BBT', 'BRK.B', 'BLK', 'BHF', 'COF', 'CBOE', 'SCHW', 'CB', 'CINF', 'C', 'CFG', 'CME', 'CMA', 'DFS', 'ETFC', 'RE', 'FITB', 'FRC', 'BEN', 'GS', 'HIG', 'HBAN', 'ICE', 'IVZ', 'JEF', 'JPM', 'KEY', 'LNC', 'L', 'MTB', 'MMC', 'MET', 'MCO', 'MS', 'MSCI', 'NDAQ', 'NTRS', 'PBCT', 'PNC', 'PFG', 'PGR', 'PRU', 'RJF', 'RF', 'SPGI', 'STT', 'STI', 'SIVB', 'SYF', 'TROW', 'TMK', 'TRV', 'USB', 'UNM', 'WFC', 'WLTW', 'ZION']

symbols = []

for i in range(len(tickers)):
    symbols.append(tickers.loc[i][0])

print (symbols)

df_list = []
used_stocks = []

for symbol in symbols:
    try:
        pricing = get_historical_data(symbol,start=start,end=end,output_format='pandas')['close']
        df_list.append(pricing)
        used_stocks.append(symbol)
    except:
        pass

stock_data = pd.concat(df_list,axis=1)
stock_data.columns = ['AMG', 'AFL', 'ALL', 'AXP', 'AIG', 'AMP', 'AON', 'AJG', 'AIZ', 'BAC', 'BK', 'BBT', 'BRK.B', 'BLK', 'BHF', 'COF', 'CBOE', 'SCHW', 'CB', 'CINF', 'C', 'CFG', 'CME', 'CMA', 'DFS', 'ETFC', 'RE', 'FITB', 'FRC', 'BEN', 'GS', 'HIG', 'HBAN', 'ICE', 'IVZ', 'JEF', 'JPM', 'KEY', 'LNC', 'L', 'MTB', 'MMC', 'MET', 'MCO', 'MS', 'MSCI', 'NDAQ', 'NTRS', 'PBCT', 'PNC', 'PFG', 'PGR', 'PRU', 'RJF', 'RF', 'SPGI', 'STT', 'STI', 'SIVB', 'SYF', 'TROW', 'TMK', 'TRV', 'USB', 'UNM', 'WFC', 'WLTW', 'ZION']
stock_data_sort = stock_data.sort_index(ascending=True)
stock_data_sort.index = pd.to_datetime(stock_data_sort.index,yearfirst=True,box=True)

performance = stock_data_sort.calc_stats()

performance.plot()
plt.show()

performance.display()

performance.stats

performance.stats.loc['cagr']

returns = stock_data.to_log_returns().dropna()

print(returns.head())

ax = returns.hist(figsize=(10,10),bins=30)
plt.show()

returns.corr().as_format('.2f')

returns.plot_corr_heatmap()
plt.show()

returns.calc_mean_var_weights().as_format('.2%')

performance.display_lookback_returns().loc['mtd']

ffn.to_drawdown_series(stock_data).plot(figsize=(15,10))
plt.show()