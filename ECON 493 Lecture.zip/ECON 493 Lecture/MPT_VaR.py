import pandas_datareader.data as web
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import datetime
from scipy.stats import norm

stock = ['AMZN','NKE','DRI','WBA','MKC','CLX','CVX','ANDV','VLO','V','JPM','CME','ESRX','MRK','CI','BA','RTN','NOC','LMT','ADBE','AAPL','NVDA','NFLX','FB','MSFT','EXR','PSA','FRT','VMC','NEE','CMS','VZ','CMCSA']

data = web.DataReader(stock,data_source="iex",start='12/09/2013',end='12/09/2018')['close']

returns = data.pct_change()

skew = returns.skew()
kurt = returns.kurt()

mean_return = returns.mean()
return_stdev = returns.std()

annualised_return = round(mean_return*252,2)
annualised_stdev = round(return_stdev*np.sqrt(252),2)

print ('The annualised mean return of stock {} is {}, and the annualised volatility is {}'.format(stock,annualised_return,annualised_stdev))

mean_daily_returns = returns.mean()
returns_stdev = returns.std()

cov_matrix = returns.cov()
weights = np.asarray([0.05, 0.03, 0.02, 0.02, 0.03, 0.03, 0.02, 0.02, 0.02, 0.05, 0.05, 0.04, 0.035, 0.035, 0.035, 0.05, 0.03, 0.03, 0.03, 0.025, 0.03, 0.05, 0.04, 0.03, 0.025, 0.03, 0.03, 0.02, 0.015, 0.02, 0.02, 0.02, 0.02])

portfolio_return = round(np.sum(mean_daily_returns * weights) * 252,2)
portfolio_std_dev = round(np.sqrt(np.dot(weights.T,np.dot(cov_matrix, weights))) * np.sqrt(252),2)

print('Portfolio expected annualised return is {} and volatility is {}'.format(portfolio_return,portfolio_std_dev))

num_portfolios = 250000

results = np.zeros((4+len(stock)-1,num_portfolios))

for i in range(num_portfolios):
    weights = np.random.random(33)
    weights /= np.sum(weights)
    portfolio_return = np.sum(mean_daily_returns * weights) * 252
    portfolio_std_dev = np.sqrt(np.dot(weights.T,np.dot(cov_matrix, weights))) * np.sqrt(252)    
    results[0,i] = portfolio_return
    results[1,i] = portfolio_std_dev
    results[2,i] = results[0,i] / results[1,i]
    for j in range(len(weights)):
        results[j+3,i] = weights[j]

results_frame = pd.DataFrame(results.T,columns=['ret','stdev','sharpe',stock[0],stock[1],stock[2],stock[3],stock[4],stock[5],stock[6],stock[7],stock[8],stock[9],stock[10],stock[11],stock[12],
    stock[13],stock[14],stock[15],stock[16],stock[17],stock[18],stock[19],stock[20],stock[21],stock[22],stock[23],stock[24],stock[25],stock[26],stock[27],stock[28],stock[29],stock[30],
    stock[31],stock[32]])

max_sharpe_port = results_frame.iloc[results_frame['sharpe'].idxmax()]
min_vol_port = results_frame.iloc[results_frame['stdev'].idxmin()]

plt.scatter(results_frame.stdev,results_frame.ret,c=results_frame.sharpe,cmap='RdYlBu')
plt.xlabel('Volatility')
plt.ylabel('Returns')
plt.colorbar()

plt.scatter(max_sharpe_port[1],max_sharpe_port[0],marker=(5,1,0),color='r',s=1000)
plt.scatter(min_vol_port[1],min_vol_port[0],marker=(5,1,0),color='g',s=1000)
plt.show()

def var_cov_var(P, c, mu, sigma):
    alpha = norm.ppf(1-c, mu, sigma)
    return abs(P - P*(alpha + 1))

if __name__ == "__main__":
    P = 1e6
    c = 0.95
    mu = np.mean(results_frame['ret'])
    sigma = np.std(results_frame['ret'])
    VaR = var_cov_var(P, c, mu, sigma)
    print ("Value-at-Risk: $%0.2f" % VaR)