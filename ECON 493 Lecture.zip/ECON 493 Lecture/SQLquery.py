# Import Libraries As Needed
# Remember To Download Libraries Needed Before Importing

import sqlite3 as db
import pandas as pd
import numpy as np

database = 'C:/sqlite/sql_databases/<database>' # PATH for Database

sql = 'SELECT <column> FROM <sql_table>;' # SQL Query

cnx = db.connect(database) # SQL Connection to DB
cur = cnx.cursor() # SQL Server Cursor

tickers = pd.read_sql(sql, con=cnx) # Read SQL DB

print (tickers) # Verify That You Have Pulled The Correct Tickers/Symbols
print (len(tickers)) # Returns Quantity of Tickers/Symbols You Have Pulled 

symbList = [] # Empty Array To Create A List of Your Tickers/Symbols For Easy Iteration

for i in range(len(tickers)):
    symbList.append(tickers.loc[i][0])

print (symbList) # Returns List of Symbols/Tickers That Can Be Easily Copy & Pasted Directly Into Quantopian!